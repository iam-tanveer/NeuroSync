
  # Neurosyn Instructor's Cognitive Dashboard

  This is a code bundle for Neurosyn Instructor's Cognitive Dashboard. The original project is available at https://www.figma.com/design/cjlipY4Fytuq8jlnGHBBk8/Neurosyn-Instructor-s-Cognitive-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  