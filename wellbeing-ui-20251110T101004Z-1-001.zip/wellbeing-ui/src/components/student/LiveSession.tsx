import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription } from '../ui/alert';
import { Brain, Activity, Music, AlertCircle, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { toast } from 'sonner';
import { AssistiveLearningTools } from './AssistiveLearningTools';

export function LiveSession() {
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionDuration, setSessionDuration] = useState(0);
  const [focusScore, setFocusScore] = useState(72);
  const [stressLevel, setStressLevel] = useState(35);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [binauralBeatsActive, setBinauralBeatsActive] = useState(false);

  // Simulate real-time updates
  useEffect(() => {
    if (!isSessionActive) return;

    const interval = setInterval(() => {
      setSessionDuration(prev => prev + 1);
      setFocusScore(prev => Math.max(40, Math.min(100, prev + (Math.random() - 0.5) * 10)));
      setStressLevel(prev => Math.max(20, Math.min(80, prev + (Math.random() - 0.5) * 8)));
    }, 1000);

    return () => clearInterval(interval);
  }, [isSessionActive]);

  // Audio feedback logic
  useEffect(() => {
    if (!audioEnabled) {
      setBinauralBeatsActive(false);
      return;
    }

    // Activate binaural beats when focus is low
    if (focusScore < 65) {
      setBinauralBeatsActive(true);
    } else {
      setBinauralBeatsActive(false);
    }
  }, [focusScore, audioEnabled]);

  // Popup tips logic
  useEffect(() => {
    if (!isSessionActive) return;

    // High stress notification
    if (stressLevel > 65) {
      toast.error('Stress Level High', {
        description: 'Take a 1-minute breathing break',
        action: {
          label: 'Start Breathing',
          onClick: () => console.log('Breathing exercise started')
        },
      });
    }

    // Low focus notification
    if (focusScore < 55) {
      toast.warning('Focus Dropping', {
        description: 'Try a quick focus exercise',
        action: {
          label: 'Focus Exercise',
          onClick: () => console.log('Focus exercise started')
        },
      });
    }
  }, [stressLevel, focusScore, isSessionActive]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getFocusColor = (score: number) => {
    if (score >= 75) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    return 'text-amber-600';
  };

  const getStressColor = (level: number) => {
    if (level >= 60) return 'text-red-600';
    if (level >= 40) return 'text-amber-600';
    return 'text-green-600';
  };

  return (
    <div className="space-y-4">
      {/* Session Controls */}
      <Card className="border-purple-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-purple-900">Study Session</CardTitle>
              <CardDescription>Track your cognitive performance in real-time</CardDescription>
            </div>
            <div className="text-purple-900">
              {formatTime(sessionDuration)}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Button
              onClick={() => setIsSessionActive(!isSessionActive)}
              className="flex-1"
              variant={isSessionActive ? 'destructive' : 'default'}
              size="lg"
            >
              {isSessionActive ? (
                <>
                  <Pause className="w-5 h-5 mr-2" />
                  End Session
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" />
                  Start Session
                </>
              )}
            </Button>
            <Button
              onClick={() => setAudioEnabled(!audioEnabled)}
              variant="outline"
              size="lg"
            >
              {audioEnabled ? (
                <Volume2 className="w-5 h-5" />
              ) : (
                <VolumeX className="w-5 h-5" />
              )}
            </Button>
          </div>

          {audioEnabled && (
            <Alert className={binauralBeatsActive ? 'border-blue-500 bg-blue-50' : 'border-green-500 bg-green-50'}>
              <Music className={`h-4 w-4 ${binauralBeatsActive ? 'text-blue-600' : 'text-green-600'}`} />
              <AlertDescription className={binauralBeatsActive ? 'text-blue-900' : 'text-green-900'}>
                {binauralBeatsActive 
                  ? 'Binaural beats activated - Boosting your focus'
                  : 'Ambient music playing - Keep it up!'}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Focus Score */}
        <Card className="border-blue-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-600" />
                <CardTitle className="text-blue-900">Focus Score</CardTitle>
              </div>
              {isSessionActive && (
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className={`${getFocusColor(focusScore)}`}>
                {focusScore.toFixed(1)}%
              </div>
              <Progress value={focusScore} className="h-4" />
              <div className="flex justify-between text-slate-600">
                <span>Low</span>
                <span>Medium</span>
                <span>High</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stress Level */}
        <Card className="border-amber-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-amber-600" />
                <CardTitle className="text-amber-900">Stress Level</CardTitle>
              </div>
              {isSessionActive && (
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className={`${getStressColor(stressLevel)}`}>
                {stressLevel.toFixed(1)}%
              </div>
              <Progress value={stressLevel} className="h-4" />
              <div className="flex justify-between text-slate-600">
                <span>Low</span>
                <span>Medium</span>
                <span>High</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Assistive Learning Tools */}
      <Card className="border-indigo-200">
        <CardHeader>
          <CardTitle className="text-indigo-900">Assistive Learning Tools</CardTitle>
          <CardDescription>Accessibility features for inclusive learning</CardDescription>
        </CardHeader>
        <CardContent>
          <AssistiveLearningTools />
        </CardContent>
      </Card>

      {/* Session Stats */}
      {isSessionActive && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-slate-500">Avg Focus</div>
              <div className="text-green-600">
                {Math.floor(Math.random() * 10 + 70)}%
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-slate-500">Avg Stress</div>
              <div className="text-amber-600">
                {Math.floor(Math.random() * 10 + 35)}%
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-slate-500">Peak Focus</div>
              <div className="text-blue-600">
                {Math.floor(Math.random() * 10 + 85)}%
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-slate-500">Breaks Taken</div>
              <div className="text-purple-600">
                {Math.floor(sessionDuration / 1500)}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
